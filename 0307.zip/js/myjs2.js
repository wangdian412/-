// 返回按钮
function back() {
    window.history.back();
}
// 确认提交按钮,需要优化
function twoSubmit() {
    window.location = "https://www.runoob.com/"
}
// 通过cookie将内容填入表格
function fillTableByCookie() {
    checkTable = document.getElementById("checkTable");
    // 获得表单元素
    uCountry = document.getElementById("uCountry");
    uReceipt = document.getElementById("uReceipt");
    uDate = document.getElementById("uDate");
    uCode = document.getElementById("uCode");
    uCompanyName = document.getElementById("uCompanyName");
    uPersonNumber = document.getElementById("uPersonNumber");
    uTotal = document.getElementById("uTotal");
    uName = document.getElementById("uName");
    uWritingDate = document.getElementById("uWritingDate");
    // 加入内容
    uCountry.innerHTML = getCookie("country");
    uReceipt.innerHTML += getCookie("receipt");
    uDate.innerHTML = getCookie("date");
    uCode.innerHTML = getCookie("code");
    uCompanyName.innerHTML = getCookie("companyName");
    uPersonNumber.innerHTML = getCookie("personNumber");
    uTotal.innerHTML = getCookie("total");
    uName.innerHTML = getCookie("name");
    uWritingDate.innerHTML = getCookie("writingDate");
}

//通过sessionStorage将值传入表格
function fillTableBySessionStorage() {
    checkTable = document.getElementById("checkTable");
    // 获得表单元素
    uCountry = document.getElementById("uCountry");
    uReceipt = document.getElementById("uReceipt");
    uDate = document.getElementById("uDate");
    uCode = document.getElementById("uCode");
    uCompanyName = document.getElementById("uCompanyName");
    uPersonNumber = document.getElementById("uPersonNumber");
    uTotal = document.getElementById("uTotal");
    uName = document.getElementById("uName");
    uWritingDate = document.getElementById("uWritingDate");
    // 加入内容
    uCountry.innerHTML = sessionStorage.getItem("country");
    uReceipt.innerHTML = sessionStorage.getItem("receipt");
    uDate.innerHTML = sessionStorage.getItem("date");
    uCode.innerHTML = sessionStorage.getItem("code");
    uCompanyName.innerHTML = sessionStorage.getItem("companyName");
    uPersonNumber.innerHTML = sessionStorage.getItem("personNumber");
    uTotal.innerHTML = sessionStorage.getItem("total");
    uName.innerHTML = sessionStorage.getItem("name");
    uWritingDate.innerHTML = sessionStorage.getItem("writingDate");
}

// 通过URL传值
function fillTableByURL() {
    //首先获取地址
    var url = window.location.href;
    var arr = url.split("?");
    //判断是否有传值
    if (arr.length == 1) {
        return null;
    }
    //获取get传值的个数
    var value_arr = arr[1].split("&");
    //循环生成返回的对象
    var obj = new Object();
    for (let i = 0; i < value_arr.length; i++) {
        var key_value = value_arr[i].split("=");
        obj[key_value[0]] = key_value[1];
    }

    checkTable = document.getElementById("checkTable");
    // 获得表单元素
    uCountry = document.getElementById("uCountry");
    uReceipt = document.getElementById("uReceipt");
    uDate = document.getElementById("uDate");
    uCode = document.getElementById("uCode");
    uCompanyName = document.getElementById("uCompanyName");
    uPersonNumber = document.getElementById("uPersonNumber");
    uTotal = document.getElementById("uTotal");
    uName = document.getElementById("uName");
    uWritingDate = document.getElementById("uWritingDate");
    // 加入内容
    uCountry.innerHTML = obj.country;
    uReceipt.innerHTML = obj.receipt;
    uDate.innerHTML = obj.date;
    uCode.innerHTML = obj.code;
    uCompanyName.innerHTML = obj.companyName;
    uPersonNumber.innerHTML = obj.personNumber;
    uTotal.innerHTML = obj.total;
    uName.innerHTML = obj.name;
    uWritingDate.innerHTML = obj.writingDate;
}
