// submit1为cookie方法
function submit1() {
    var form0 = document.getElementById("form0");
    // form0.setAttribute("action", "孙志强0307跳转页.html");
    if (isNoEmpty()) {   // 如果必填项全部填入
        // 如果点了记住我,username加入cookie中
        rememberMe();
        // 将表格内容加入cookie
        addInCookie();
        // 执行提交
        form0.submit();
    }
}

// submit2为Window sessionStorage方法
function submit2() {
    var form0 = document.getElementById("form0");
    // form0.setAttribute("action", "孙志强0307跳转页.html");
    // 如果必填项全部填入
    if (!isNoEmpty()) {
    } else {
        rememberMe();
        // 将表格内容加入SessionStorage
        addInSessionStorage();
        // 执行提交
        form0.submit();
    }
}
// submit3为get方法
function submit3() {
    var form0 = document.getElementById("form0");
    // form0.setAttribute("action", "孙志强0307跳转页.html");
    if (isNoEmpty()) {
        // 如果必填项全部填入
        rememberMe();
        // 执行提交
        form0.submit();
    }
}

//判断是否有空必选项的结果
function isNoEmpty() {
    // 选择所有的must类
    var must = document.getElementsByClassName("must form-control");
    // 如果都填了.还是true
    var checkFlag = true;
    for (const iterator of must) {
        if (iterator.value == null || iterator.value == "") {
            // 没填的必选项背景变为红色,旗杆变为false
            iterator.style.background = "red";
            checkFlag = false;
        }
    }
    // 如果旗杆为false,说明有必选项未填写
    if (!checkFlag) {
        alert("有必选项未填写");
        return false;
    } else {
        return true;
    }
}
// 设置欢迎页,onload方法
function welcome() {
    var name = getCookie("username");
    if (name != "" || name != null) {
        alert("欢迎" + name + "再次访问");
    }
}

// setCookie方法
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires;
}
// getCookie方法
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(";");
    for (let i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
// 如果点了记住我,将username加入cookie中
function rememberMe() {
    var rem = document.getElementById("rememberMe");
    if (rem.checked) {  //如果记住我选项被选中
        name = prompt("请输入你的名字");
        if (name != "" && name != null) {
            // 已经加入到cookie中了
            setCookie("username", name, 30);
        }
    }
}
// 加入表单内容进cookie
function addInCookie() {
    var form0 = document.getElementById("form0");

    // 查找国家一栏
    var sCountry = document.getElementsByName("country");
    // 遍历国家单选框选项
    for (let i = 0; i < sCountry.length; i++) {
        // 如果有被选中的,加入cookie
        if (sCountry[i].checked) {
            setCookie("country", sCountry[i].value, 7);
        }
    }
    // 从第二栏开始,获取其内容,加入cookie
    for (let i = 2; i < 11; i++) {
        console.log(form0[i].value)
        setCookie(form0[i].name, form0[i].value, 7);
    }
}
// 加入表单内容进SessionStorage
function addInSessionStorage() {
    var form0 = document.getElementById("form0");
    // 查找国家一栏
    var sCountry = document.getElementsByName("country");
    // 遍历国家单选框选项
    for (let i = 0; i < sCountry.length; i++) {
        // 如果国家中有被选中的,加入sessionStorage
        if (sCountry[i].checked) {
            sessionStorage.setItem("country", sCountry[i].value);
        }
    }
    // 从第三栏开始,获取其内容,一直到文件栏
    console.log(sessionStorage.getItem("country"));
    for (let i = 2; i < 11; i++) {
        // 将值传入sessionStorage中
        sessionStorage.setItem(form0[i].name, form0[i].value);
    }

}


